const https = require('https')

exports.handler = async (event, context) => requestHackernoon();

const requestHackernoon = () => {
    return new Promise((resolve,reject)=>{
        let dataString = '';
        const req = https.get("https://hn.algolia.com/api/v1/search_by_date?query=nodejs", (response)=> {
            resolve(response)
        }).on('error', (e)=>{
            reject(`error: ${e}`)
        });
    });
}